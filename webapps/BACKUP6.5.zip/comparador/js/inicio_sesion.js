$(document).ready(function() {
    console.log("ready!");


	$("#Registro").click(function() {
 	 // Código a ejecutar cuando el usuario haga click
	 event.preventDefault();
		window.location.href="/comparador/registro";
  		
	});
});

