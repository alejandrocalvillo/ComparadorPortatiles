$(document).ready(function() {
    console.log("ready!");


	$("#IniciarSesion").click(function() {
 	 // Código a ejecutar cuando el usuario haga click
		window.location.href="/comparador/login";
  		
	});
});

